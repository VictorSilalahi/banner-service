<?php

namespace Exception;

class BadRequestException extends \Exception
{
}
