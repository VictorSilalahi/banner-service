<?php

namespace Exception;

class PreconditionRequiredException extends \Exception
{
}
